__all__ = ['SimpleCutoff', 'TopPercentageCutoff', 'BetavalueDistribution']
